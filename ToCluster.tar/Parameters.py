CPMin = -1.0
CPMax = 1.0
dX = 0.5
